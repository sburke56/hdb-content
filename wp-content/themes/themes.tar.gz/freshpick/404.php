<?php get_header(); ?>

	<div id="content-outer" class="clear"><div id="content-wrap">
	
		<div id="content">
		
			<div id="left">

		<h2 class="center">Error 404 - Not Found</h2>

			
			</div>
		
<?php get_footer(); ?>