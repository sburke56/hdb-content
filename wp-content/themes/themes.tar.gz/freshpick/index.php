<?php get_header(); ?>

<?php if (is_home() && !is_paged()) {
$sticky=get_option('sticky_posts');
$the_query = new WP_Query('showposts=1&p=1' . $sticky[0]);
if ($the_query->have_posts()) :
    while ($the_query->have_posts()) : $the_query->the_post();
$do_not_duplicate = $post->ID;
?>
<!-- featured starts -->	
<div id="featured" class="clear">				


<div class="image-block">
    <?php wp_cycle(); ?>
</div>			

<div class="text-block">
  
  <h2><div id="homepage-post-title"><?php the_title(); ?></div></h2>
  <?php the_excerpt(); ?>				
  
</div>


<!-- featured ends -->	
</div>

<?php endwhile; endif; } ?>

<!-- content -->
<div id="content-outer2" class="clear">
  <div id="content-wrap2">  
  <div id="content2">
  

  <?php get_footer(); ?>
