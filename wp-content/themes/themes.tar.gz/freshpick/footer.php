<?php
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}
?>
</div>
<!-- content end -->	
</div></div>
  
  <!-- footer-bottom starts -->		
  <div id="footer-bottom">
    <div class="bottom-left">
      <p>
	&copy; <?php echo date('Y'); ?> <strong><?php bloginfo('name'); ?></strong>&nbsp; &nbsp; &nbsp;<br>
	Custom made cakes & catering in Frisco, Texas.
      </p>
    </div> 
    <div class="bottom-right"> 
      <p>
        <a href="http://www.styleshout.com/">styleshout</a> | <a href="http://www.themelab.com">Theme Lab</a>
      </p>
    </div> 
    <!-- footer-bottom ends -->		
  </div>
  
  <!-- wrap ends here -->
</div>
<?php wp_footer(); ?>
</body>
</html>
